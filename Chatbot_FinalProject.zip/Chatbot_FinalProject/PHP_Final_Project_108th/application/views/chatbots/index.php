<body>
	<div class="statics">
		<a href="<?php echo site_url('/chatbots/hot'); ?>">文章排行</a>
		<a href="<?php echo site_url('/chatbots/tag'); ?>">標籤排行</a>
		<a href="<?php echo site_url('/chatbots/user_articles'); ?>">文章發表排行</a>
	</div>
</body>
