<h1>首頁</h1>

<a href="<?php echo site_url('articles'); ?>">文章</a>
