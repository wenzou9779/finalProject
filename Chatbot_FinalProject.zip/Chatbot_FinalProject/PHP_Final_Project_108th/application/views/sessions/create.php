<div class="wrap">
	<?php echo form_open('sessions/creating') ?>
		<div class="data">
			<label for="email">帳號</label>
		    <input type="input" name="email" /><br />
		</div>
		<div class="data">
		    <label for="password">密碼</label>
		    <input type="password" name="password" /><br />
		</div>
		<div class="confirm">
	    <input type="submit" name="submit" value="登入" />
	    </div>
	</form>
</div>
