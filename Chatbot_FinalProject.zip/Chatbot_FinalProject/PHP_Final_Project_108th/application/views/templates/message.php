<?php if ($this->session->flashdata('message')): ?>
    <div><?php echo $this->session->flashdata('message'); ?></div>
<?php endif; ?>
